# B-Town Print Studio — website sample: chat context

Session: https://claude.ai/code/session_01T5svXz4iyEGScnytJCuKYv
Repo branch: shehaakb/NightingaleEvents @ claude/eloquent-ride-bx8b6w (folder btown-print-studio/)
Preview: open site/index.html in a browser (or serve the folder: `python3 -m http.server 5173`).

## The brief (from Sheha)
- New inquiry from a peer in the wedding industry: a large format print studio in Brampton (Instagram: @btownprintstudio).
- Build something in the spirit of the Nightingale and EDA sites, but the main goal is self-serve ordering:
  clients upload their own artwork, choose a size, see the price instantly, and check out on the site.
  Today they email the studio and it drains staff time.
- "Instant quote" generator: upload artwork, choose a size, and show a rendering that compares it to an
  average 5'5" person's silhouette, because most people can't picture 7x3 vs 5x2.
- Aesthetic: high converting, fun and playful.
- SEO: "Brampton & the GTA's go-to, most reliable print shop" and copy along those lines.
- Copy focus: affordability, fast turnaround, graphic design services to bring your vision to life.
- Palette: the "Just Peachy" brand board (coral, peach, blush, cream, lime, teal). Second mood board: pink
  Canon printer / clean-girl aesthetic.
- Home page scroll animation: something printing as you scroll (reference Pinterest pin 1040120476456344967).
- Follow-up: headline idea "All your printing needs - big, small and everything in between - in one shop.
  Fast and affordable!" Show the Canon large format printer (recolored, black too harsh) printing the
  supplied signs (backgrounds removed) as a looped animation that activates on scroll.
- Two more prints were sent (a lilac/olive bar menu and a cream "Penelope and Edward" fabric banner) but
  they did not arrive as files in the session, so they are not in the loop yet.

## What was built (site/index.html, single file)
- Sticky nav, ticker bar, hero with headline + CTAs + trust stats.
- Hero animation: coral-tinted printer (assets/printer.png); four signs (menu, acrylic monogram, place cards,
  seating chart) feed out of the printer slot one after another in a loop. Runs while in view, scrubs with
  scroll, label pill names each product. Reduced-motion gets a static frame.
- Instant quote generator: drag/drop or click upload (image previews on the banner), product dropdown with
  per-sq-ft rates and minimums (placeholders), size presets + custom inches, quantity with volume discounts,
  48h rush (+30%), live total / per-piece / ETA. "Add to cart" is a demo alert.
- Real-size preview: banner scales next to a 5'5" silhouette with grommets and "x times taller than a
  person" callout.
- Services grid with "from" pricing, Why Us, 4-step process, reviews, Brampton/GTA SEO section, FAQ, CTA,
  footer. LocalBusiness JSON-LD, meta title/description, canonical, OG tags.
- Fonts: Fraunces (display) + DM Sans (body) via Google Fonts.

## Placeholders to replace with her real info
- Business name "B-Town Print Studio", phone (905) 000-0000, address, email, review count, prices,
  client logos row, testimonials, Instagram link.
- Checkout integration (Stripe/Shopify) and file storage for uploads.

## Known gaps / next steps
- Instagram and Pinterest were blocked from the build container, so brand feel came from the attached boards only.
- Add the two missing prints to the loop (one <div class="print"> line each in the #feed block).
- Mobile pass on the hero scene (currently scaled 0.85 under 900px).
- Replace placeholder rates in the product <select> with her real price table.

## Folder contents
- site/            the homepage and processed assets (printer.png, menu.png, monogram.png, placecards.png, seating.png)
- source-images/   the original files attached in chat (brand boards, printer, signs)
- screenshots/     hero, hero animation frames, quote widget at 6x3 and 10x8
